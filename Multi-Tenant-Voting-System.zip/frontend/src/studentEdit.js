// Shared logic for the two student-edit screens (superadmin "Student Changes" and the
// standalone IT admin screen). Only logic lives here: no layout, so the two UIs stay separate.
// Both screens call the SAME backend endpoint (POST /admin/students/edit).
import api from './api';
import { getIdText } from './idText';

export const lookupStudents = (q) =>
  api.get('/admin/students/lookup', { params: { q } }).then((r) => r.data);

export const fetchEditHistory = (q = '') =>
  api.get('/admin/students/edit-history', { params: { q, limit: 100 } }).then((r) => r.data.entries);

export const saveStudentEdit = (body) =>
  api.post('/admin/students/edit', body).then((r) => r.data);

// Same rules as the backend's normalize_phone_number, so the preview matches what is saved.
export function previewPhone(raw) {
  let clean = String(raw || '').replace(/\D/g, '');
  if (clean.startsWith('0')) clean = '256' + clean.slice(1);
  else if (clean.length === 9 && (clean.startsWith('7') || clean.startsWith('4'))) clean = '256' + clean;
  return clean.length >= 10 && clean.length <= 15 ? clean : null;
}

const normId = (s) => String(s || '').trim().replace(/"/g, '').replace(/\s+/g, '').toLowerCase();
const cleanName = (s) => String(s || '').split(/\s+/).filter(Boolean).join(' ');

export function draftFromStudent(s) {
  return {
    original: s,
    full_name: s.full_name,
    new_student_id: s.student_id,
    attrs: { ...(s.attrs || {}) },
    phones: (s.phone_numbers || []).map((n, i) => ({ key: `o${i}`, index: i, original: n, value: n, removed: false })),
  };
}

let newKey = 0;
export const withNewPhoneRow = (d) => ({
  ...d, phones: [...d.phones, { key: `n${newKey++}`, index: null, original: null, value: '', removed: false }],
});

/** Everything a screen needs to render "current -> new" and to send the save. */
export function computeChanges(d) {
  const rows = [];
  const errors = [];
  const ops = { change: [], remove: [], add: [], attrs: [] };

  const name = cleanName(d.full_name);
  if (!name) errors.push('Name cannot be empty.');
  else if (name !== d.original.full_name) rows.push({ id: 'name', label: 'Name', from: d.original.full_name, to: name });

  const sid = normId(d.new_student_id);
  if (!sid) errors.push(`${getIdText().nounCap} cannot be empty.`);
  else if (sid !== d.original.student_id) {
    rows.push({ id: 'sid', label: getIdText().short, from: d.original.student_id, to: sid });
  }

  d.phones.forEach((p) => {
    if (p.index !== null) {
      if (p.removed) {
        rows.push({ id: p.key, label: 'Phone removed', from: p.original, to: null });
        ops.remove.push({ op: 'remove', index: p.index, expected_old: p.original });
        return;
      }
      const n = previewPhone(p.value);
      if (!n) errors.push(`"${p.value}" is not a valid phone number.`);
      else if (n !== p.original) {
        rows.push({ id: p.key, label: 'Phone changed', from: p.original, to: n });
        ops.change.push({ op: 'change', index: p.index, expected_old: p.original, number: p.value });
      }
    } else if (!p.removed && p.value.trim()) {
      const n = previewPhone(p.value);
      if (!n) errors.push(`"${p.value}" is not a valid phone number.`);
      else rows.push({ id: p.key, label: 'Phone added', from: null, to: n });
      if (n) ops.add.push({ op: 'add', number: p.value });
    }
  });

  Object.keys(d.original.attrs || {}).forEach((key) => {
    const from = d.original.attrs[key] || '';
    const to = String(d.attrs?.[key] || '').trim();
    if (from !== to) {
      rows.push({ id: `attr:${key}`, label: key, from: from || null, to: to || null });
      ops.attrs.push({ key, expected_old: from || null, value: to || null });
    }
  });
  Object.keys(d.attrs || {}).filter(key => !(key in (d.original.attrs || {}))).forEach((key) => {
    const to = String(d.attrs[key] || '').trim();
    if (to) {
      rows.push({ id: `attr:${key}`, label: key, from: null, to });
      ops.attrs.push({ key, expected_old: null, value: to });
    }
  });

  const remaining = d.phones.filter((p) => !p.removed && (p.index !== null || p.value.trim())).length;
  const warnings = [];
  if (rows.length && remaining === 0) {
    warnings.push('This student will have no phone number and cannot receive a voting OTP.');
  }
  return { rows, errors, warnings, ops, hasChanges: rows.length > 0 };
}

/** Removes go highest-index first so earlier positions stay valid on the server. */
export function buildPayload(d, reason) {
  const { rows, ops } = computeChanges(d);
  const has = (id) => rows.some((r) => r.id === id);
  return {
    student_id: d.original.student_id,
    full_name: has('name') ? cleanName(d.full_name) : undefined,
    new_student_id: has('sid') ? d.new_student_id : undefined,
    phone_ops: [...ops.change, ...[...ops.remove].sort((a, b) => b.index - a.index), ...ops.add],
    attr_ops: ops.attrs,
    reason: reason.trim(),
  };
}

export const EVENT_LABELS = {
  student_name_changed: 'Name changed',
  student_attr_changed: 'Optional field changed',
  get student_registration_number_changed() { return `${getIdText().nounCap} changed`; },
  phone_added: 'Phone added',
  phone_removed: 'Phone removed',
  phone_changed: 'Phone changed',
};

// FastAPI returns `detail` as a string, or as an array on validation errors (422).
export function errMsg(e, fallback) {
  const d = e?.response?.data?.detail;
  if (typeof d === 'string' && d.trim()) return d;
  if (Array.isArray(d)) return d.map((x) => x?.msg || JSON.stringify(x)).join(', ');
  return fallback;
}

// ── OTP_SMS_Design_v2: roster freeze + contact-change requests ──────────────
export const fetchRosterStatus = () => api.get('/admin/roster-status').then((r) => r.data);
export const submitContactChange = (body) => api.post('/it-admin/contact-changes/request', body).then((r) => r.data);
export const listContactChanges = (status) =>
  api.get('/admin/contact-changes', { params: status ? { status } : {} }).then((r) => r.data);
export const cancelContactChange = (id, reason = '') =>
  api.post(`/it-admin/contact-changes/${id}/cancel`, { reason }).then((r) => r.data);
export const decideContactChange = (id, body) =>
  api.post(`/admin/contact-changes/${id}/decide`, body).then((r) => r.data);
// Superadmin only, and only when "break-glass" is switched on in Security & SMS.
export const breakGlassApprove = (id, body) =>
  api.post(`/superadmin/contact-changes/${id}/force-approve`, { decision: 'approve', ...body }).then((r) => r.data);
export const undoDigestEntry = (id, reason) =>
  api.post(`/admin/contact-changes/digest/${id}/undo`, { reason }).then((r) => r.data);

export const EVIDENCE_TYPES = [
  ['id_card_in_person', 'Student ID card checked in person'],
  ['registrar_record', 'Registrar record'],
  ['student_portal_record', 'Student portal record'],
  ['commission_verified_by_call', 'Commission verified by call'],
  ['other_documented', 'Other (documented, 20+ characters)'],
];
export const CHANGE_LABELS = {
  phone_change: 'Change phone number', phone_add: 'Add phone number',
  phone_remove: 'Remove phone number', get registration_number_change() { return `Change ${getIdText().noun}`; },
};
