import React, { useState, useEffect, useRef, lazy, Suspense } from 'react'; 
import api, { API_BASE, ADMIN_TOKEN_KEY } from './api';
import { LoadingBlock } from './components/Spinner';
import { loginGuidance, UNCONFIRMED_DELIVERY_NOTE } from './loginErrors';
import { setIdText } from './idText';
import { setBrand } from './brandColors';
import OtpInput from './components/OtpInput';
import PhaseBanner from './components/PhaseBanner';
import { HelpMenuProvider } from './context/HelpMenuContext';
import LoginErrorActions from './components/LoginErrorActions';
import HelpPanel from './components/HelpPanel';
import { initAnalytics, trackPage, pageName } from './analytics';
import { getTemplate } from './template';
import { logoNeedsInvertFromPixels } from './logoInvert';

// Detects whether a logo image is dark, colourless line-art (e.g. black linework on a
// transparent PNG) so it can be inverted to stay visible against the dark
// theme's dark page background. Full-colour logos are left alone (see logoInvert.js). Falls back to "don't invert" whenever the
// image can't be sampled (not loaded yet, or a CORS-tainted canvas), which
// is the safe default for arbitrary org-uploaded logos.
function useLogoNeedsInvert(logoUrl, theme) {
  // Result is keyed by the logo it was measured for, so a stale result for an old logo/theme is
  // ignored without resetting state synchronously inside the effect.
  const [result, setResult] = useState({ url: null, invert: false });
  useEffect(() => {
    if (!logoUrl || theme !== 'dark') return;
    let cancelled = false;
    const done = (invert) => { if (!cancelled) setResult({ url: logoUrl, invert }); };
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || img.width;
        canvas.height = img.naturalHeight || img.height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height);
        done(logoNeedsInvertFromPixels(data)); // dark AND colourless only: a full-colour badge must keep its colours
      } catch {
        done(false); // CORS-tainted or unreadable — fail safe
      }
    };
    img.onerror = () => done(false);
    img.src = logoUrl;
    return () => { cancelled = true; };
  }, [logoUrl, theme]);
  return Boolean(logoUrl) && theme === 'dark' && result.url === logoUrl && result.invert;
}
import { FabTrigger } from './components/HelpTriggers';
import { showHelpFab } from './helpItems';
import DemoInbox from './components/DemoInbox';
import usePolling from './hooks/usePolling';
import { fetchBootstrap } from './bootstrap';
import { Icon } from './components/icons.jsx';
import TurnstileWidget from './components/TurnstileWidget';
import VoterLoginInputs from './components/VoterLoginInputs';
import { useOptionalConfirm } from './components/UIFeedback';
import { turnstileConfigured } from './supportLink';
import {
  restoreAdminView, loadPublicView, savePublicView,
  loadVoterProgress, saveVoterProgress, clearVoterProgress, clearVoterSession,
  saveVoterToken, clearVoterToken, loadResendSeconds, saveResendDeadline,
  clearAdminSession, markPasswordChangePending, clearPasswordChangePending,
} from './session';

// Heavy, role-specific screens load on demand so a voter's first paint isn't paying for every dashboard.
const BallotBoxLazy = lazy(() => import('./components/BallotBox'));
// Wrapper so both call sites (real ballot, sample-ballot preview) get a Suspense boundary without JSX changes.
function BallotBox(props) {
  return <Suspense fallback={<LoadingBlock text="Loading ballot…" />}><BallotBoxLazy {...props} /></Suspense>;
}
const Results = lazy(() => import('./components/Results'));
const SuperAdminDashboard = lazy(() => import('./components/SuperAdminDashboard'));
const CommissionDashboard = lazy(() => import('./components/CommissionDashboard'));
const VettingDashboard = lazy(() => import('./components/VettingDashboard'));
const ApplicantPortal = lazy(() => import('./components/ApplicantPortal'));
const ITAdminDashboard = lazy(() => import('./components/ITAdminDashboard'));
const FinancialControllerDashboard = lazy(() => import('./components/FinancialControllerDashboard'));
const OverseerDashboard = lazy(() => import('./components/OverseerDashboard'));
const CandidateStatusPortal = lazy(() => import('./components/CandidateStatusPortal'));
const VerifyCertificate = lazy(() => import('./components/VerifyCertificate'));
const HeatmapOverlay = lazy(() => import('./components/HeatmapOverlay'));


// ?heatmap=<page> renders one public page for the heatmap modal. Only for a real superadmin session
// (the API enforces the role too); tracking is off inside the frame (see analytics.js).
const HEATMAP_VIEWS = { voter_identity: 'voter', results: 'results', apply: 'apply' };
const HEATMAP_FRAME = (() => {
  try {
    const p = new URLSearchParams(window.location.search).get('heatmap');
    const ok = p && HEATMAP_VIEWS[p] && sessionStorage.getItem('admin_role') === 'superadmin' && sessionStorage.getItem(ADMIN_TOKEN_KEY);
    return ok ? { page: p, view: HEATMAP_VIEWS[p] } : null;
  } catch { return null; }
})();

// Matched once per render (cheap, and the pathname doesn't change without a
// reload in this session-state-driven SPA) rather than as a hook — it must
// be readable before deciding whether to run the rest of App's hooks' work.
function matchStatusToken() {
  return window.location.pathname.match(/^\/status\/([A-Za-z0-9_-]+)$/)?.[1] || null;
}

function matchVerifyId() {
  return window.location.pathname.match(/^\/verify\/([A-Za-z0-9_-]+)$/)?.[1] || null;
}

function App() {
  const statusToken = matchStatusToken();
  const verifyId = matchVerifyId();
  const [supportContacts, setSupportContacts] = useState([]);
  const [supportPhone, setSupportPhone] = useState("");
  const [showGuide, setShowGuide] = useState(false); // New state for Guide
  const [candidates, setCandidates] = useState([]); // To store candidates for preview
  // Decide ONCE, before the first render, where to resume after a reload
  // (pull-to-refresh, F5, a discarded background tab). Everything below used
  // to start from "voter login, step 1" unconditionally, which dropped even
  // signed-in admins and OTP-verified voters back on the login screen.
  // Priority: a public page (Results/Apply) the person was on, then a
  // still-valid admin session, then a voter mid-flow.
  const [restored] = useState(() => {
    const adminView = restoreAdminView();          // null if none / expired
    const pub = loadPublicView();
    if (pub) return { view: pub, adminView };
    if (adminView) return { view: adminView, adminView };
    const vp = loadVoterProgress();
    if (vp) return { view: "voter", ...vp };
    return {};
  });
  const [step, setStep] = useState(HEATMAP_FRAME ? 1 : (restored.step || 1)); 
  const [view, setView] = useState(HEATMAP_FRAME ? HEATMAP_FRAME.view : (restored.view || "voter")); 
  useEffect(() => { initAnalytics(); }, []);
  // Mirrors sessionStorage's "admin_role" in React state so the nav can react
  // to it. Lets a logged-in admin who has navigated to Results/Apply/Vote get
  // back to their dashboard with one click, instead of refreshing or hitting
  // "Vote Now" — which calls resetFlow() and signs them out entirely.
  const [adminRole, setAdminRole] = useState(restored.adminView || null);
  const [studentId, setStudentId] = useState(restored.studentId || "");
  const [name, setName] = useState("");
  const [otp, setOtp] = useState("");
  const [isAdminPath, setIsAdminPath] = useState(false);
  useEffect(() => {
    const name = pageName(view, step, isAdminPath);
    if (name) trackPage(name);
  }, [view, step, isAdminPath]);
  const [totpCode, setTotpCode] = useState("");
  const [needsTotp, setNeedsTotp] = useState(false);
  const [isElectionOpen, setIsElectionOpen] = useState(true);
  const [electionStatus, setElectionStatus] = useState(null);
  // Cloudflare Turnstile (voter code requests only). The token is single-use, so every attempt
  // bumps `captchaKey` to fetch a fresh one. `captchaForced` flips on when the server asks for the
  // check even though the org mode isn't "on" (adaptive on a flagged IP, or under attack).
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaKey, setCaptchaKey] = useState(0);
  const [captchaForced, setCaptchaForced] = useState(false);
  const [maskedNumbers, setMaskedNumbers] = useState([]);
  // Splash: static build-time values only, never touched by the DB.
  const bootName = import.meta.env.VITE_ELECTION_NAME || "";
  const bootLogoUrl = import.meta.env.VITE_LOGO_URL || "";
  // Header: dynamic branding only, no Vite fallback.
  const [orgName, setOrgName] = useState("");
  const [timer, setTimer] = useState(() => (restored.step === 2 ? loadResendSeconds() : 0));
  const [selectedPhone, setSelectedPhone] = useState(restored.selectedPhone || "");
  // Which number the voter picked (multi-phone voters). Resend must repeat it, or the server answers
  // needs_selection and bounces them back to the picker instead of sending a new SMS (guide 4.8 #5).
  const phoneIdxRef = useRef(null);
  // Last /verify-otp failure (wrong code, tries left, lockout countdown) shown inline by OtpInput (guide 4.8 #1).
  const [otpFeedback, setOtpFeedback] = useState(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [statusModal, setStatusModal] = useState({ 
    show: false, 
    title: '', 
    message: '', 
    type: 'success' 
  });
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [pendingAdminEmail, setPendingAdminEmail]     = useState('');
  // Captured from the login form the moment the temp-password login succeeds,
  // so the forced password-change modal doesn't have to ask the admin to
  // retype the code they just entered. Still sent to /admin/set-password as
  // old_password so the backend keeps verifying it server-side.
  const [pendingTempPassword, setPendingTempPassword] = useState('');
  const [newPasswordForm, setNewPasswordForm]         = useState({ new_password: '', confirm_password: '' });
  const [passwordChangeError, setPasswordChangeError] = useState('');
  const [passwordChangeSubmitting, setPasswordChangeSubmitting] = useState(false);
  // Instant, zero-network fallback for the splash: baked into the build per
  // org (same pattern as VITE_ORG_SLUG in api.js), so the very first paint
  // already has the right name/logo instead of a generic placeholder while
  // /superadmin/branding is still in flight. The Mongo-backed branding call
  // still runs and can override these (colors, an updated logo, etc.) — env
  // vars just mean there's nothing to wait on for the first frame.
  const [logoUrl, setLogoUrl] = useState("");
  // Gates the very first paint of the real app. "Ready" here means two
  // things are both true: the backend is actually reachable (checked via
  // /health, not /superadmin/branding — a plain ping, unauthenticated,
  // org-exempt, so it's the fastest true signal that "this tenant's backend
  // is up" without pulling in branding/auth concerns), AND a short minimum
  // floor has elapsed so the splash never flashes on/off in one frame on a
  // fast connection. It does NOT wait a fixed period regardless of state —
  // that would add fake latency for fast users and false confidence for
  // slow ones. See bootExiting below for the animated hand-off.
  const [bootReady, setBootReady] = useState(false);
  const [bootExiting, setBootExiting] = useState(false);
  // The splash is only worth showing if the server is NOT answering straight away (see the boot effect).
  const [bootSplashDue, setBootSplashDue] = useState(false);
  // Where the splash is in its one-way story:
  //   connecting -> (starting, only if the server is actually cold) -> initializing -> connected
  // It only ever moves forward. A warm server skips "starting" entirely; a cold one shows it
  // for as long as it really takes, then flows on to "initializing" and "connected" once
  // /health answers, instead of flipping back and forth between labels.
  const [bootStage, setBootStage] = useState('connecting');
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem('theme');
    if (saved === 'light' || saved === 'dark') return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const logoNeedsInvert = useLogoNeedsInvert(logoUrl, theme);
  const logoStyle = {
    height: '120px',
    width: 'auto',
    objectFit: 'contain',
    margin: '0 10px',
    filter: logoNeedsInvert
      ? 'invert(1) hue-rotate(180deg) drop-shadow(0px 0px 4px rgba(241, 196, 15, 0.3))'
      : 'drop-shadow(0px 0px 4px rgba(241, 196, 15, 0.3))',
  };

  const toggleTheme = () => setTheme(t => (t === 'dark' ? 'light' : 'dark'));

  
// --- USEEFFECTS ---
useEffect(() => {
  // Render's free tier spins the backend down when idle and can take 30-50+
  // seconds to cold-start on the next request. That makes a fixed timeout
  // actively harmful here: releasing the splash before the backend is truly
  // up doesn't make the wait shorter, it just drops the visitor into a
  // normal-looking login screen that then fails every request for the next
  // 40 seconds — which reads as far more broken than staying on the splash.
  // So this polls /health for real success instead of giving up on a clock,
  // and the copy is honest about *why* it's slow past the point where a
  // warm backend would have already answered.
  const POLL_INTERVAL_MS = 2500; // spacing between retries while cold-starting
  const COLD_HINT_MS = 1500;     // no answer by now = the server is waking up, not just a slow first paint
  const INIT_MS = 800;           // how long "initializing secure connection" stays visible
  const CONNECTED_MS = 600;      // how long "connected" shows before the hand-off
  const EXIT_ANIM_MS = 350;      // must match the CSS transition on the splash
  // Boot probe: "/" (bare API root), not "/health". Content blockers (iPhone Safari, Brave Shields) can drop
  // requests to well-known monitoring paths like /health; the root is a plain page load they leave alone. It does
  // no DB work, so it is also the cheapest possible wake-up poke. The secret keep-warm cron path is NOT used
  // here on purpose: putting it in the bundle would publish it.
  const BOOT_PROBE_PATH = '/';
  const WARM_MS = 500;           // /health answered inside this = warm server: skip the splash entirely

  let cancelled = false;
  let pollTimer = null;
  const stageTimers = [];

  // Warm server: /health comes back almost instantly, so flashing a ~2s splash would only slow people
  // down. Hold the splash back for WARM_MS; if /health answers first, go straight to the app.
  let splashShown = false;
  const splashTimer = setTimeout(() => {
    if (cancelled) return;
    splashShown = true;
    setBootSplashDue(true);
  }, WARM_MS);

  // Only claim "starting server" once the wait has outlasted a warm response.
  const coldHintTimer = setTimeout(() => {
    if (!cancelled) setBootStage(st => (st === 'connecting' ? 'starting' : st));
  }, COLD_HINT_MS);

  const finish = () => {
    if (cancelled) return;
    cancelled = true;
    clearTimeout(coldHintTimer);
    clearTimeout(pollTimer);
    clearTimeout(splashTimer);
    if (!splashShown) { setBootReady(true); return; }   // warm: nothing was ever shown, nothing to animate out
    // /health answered: the server is up. Walk forward through the last two steps.
    setBootStage('initializing');
    stageTimers.push(setTimeout(() => setBootStage('connected'), INIT_MS));
    stageTimers.push(setTimeout(() => {
      // Animate out rather than unmounting straight away, so "ready" reads
      // as a deliberate hand-off instead of a jump-cut.
      setBootExiting(true);
      stageTimers.push(setTimeout(() => setBootReady(true), EXIT_ANIM_MS));
    }, INIT_MS + CONNECTED_MS));
  };

  const poll = () => {
    api.get(BOOT_PROBE_PATH, { __noRetry: true }).then(finish).catch(() => {
      if (!cancelled) pollTimer = setTimeout(poll, POLL_INTERVAL_MS);
    });
  };
  poll();

  fetchBootstrap().then(boot => {
    const res = { data: boot.branding };
    if (!res.data) return;
    setIdText(res.data);   // this organisation's ID label / example wording (Branding)
    if (res.data.support_phone) setSupportPhone(res.data.support_phone);
    if (Array.isArray(res.data.support_contacts)) setSupportContacts(res.data.support_contacts);
    if (res.data.logo_url) {
      setLogoUrl(res.data.logo_url);
      // Update browser tab favicon dynamically
      const favicon = document.querySelector("link[rel='icon']");
      if (favicon) favicon.href = res.data.logo_url;
    }
    // raw brand colours + their readable-ink / surface-safe variants, for both templates (brandColors.js)
    setBrand(res.data);
    // Header name always comes from dynamic branding.
    if (res.data.org_name) setOrgName(res.data.org_name);

    // Update browser tab title dynamically
    if (res.data.org_name) document.title = `${res.data.org_name} Election Portal`;
  }).catch(() => {
    // Branding is enrichment, not a boot gate — the env fallback (already
    // showing) is enough if this fails. Silent by design.
  });

  return () => { cancelled = true; clearTimeout(coldHintTimer); clearTimeout(pollTimer); clearTimeout(splashTimer); stageTimers.forEach(clearTimeout); };
}, []);
  
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const { status } = await fetchBootstrap();   // shares the one startup request with branding (E1)
        if (!status) throw new Error('no status');
        setIsElectionOpen(status.is_open);
        setElectionStatus(status);
      } catch {
        console.error("Could not fetch election status");
      }
    };
    checkStatus();
  }, []);

  // Voting/applications can open or close while a page is open; keep the button and notice current.
  usePolling(async () => {
    const res = await api.get('/election-status');
    setIsElectionOpen(res.data.is_open);
    setElectionStatus(res.data);
  }, 60000);   // phases change on the scale of hours/days; 60 s is plenty (guide 3.3)

  useEffect(() => {
    let interval = null;
    if (timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [timer]);

    // Only needed for the sample-ballot guide, so fetch when it is opened rather than for every visitor.
    useEffect(() => {
      if (!showGuide) return;
      const fetchCandidates = async () => {
        try {
          const res = await api.get('/candidates');
          setCandidates(res.data);
        } catch (err) {
          console.error("Error fetching candidates for guide", err);
        }
      };
      fetchCandidates();
    }, [showGuide]);

  // --- SESSION PERSISTENCE ---
  // Remember which public page is open so a reload doesn't bounce off it.
  useEffect(() => { savePublicView(view); }, [view]);

  // The voter is one OTP away from the ballot: fetch its chunk now so stepping to it is instant (guide 3.1).
  useEffect(() => { if (step === 2) import('./components/BallotBox').catch(() => {}); }, [step]);

  // Remember the voter's place in the flow (never the OTP itself). Going back
  // to step 1 / 1.5 means the session is over, so forget it.
  useEffect(() => {
    if (view !== "voter" || isAdminPath) return;
    if ([2, 3, 4].includes(step) && studentId) {
      saveVoterProgress({ step, studentId, selectedPhone });
    } else if (step === 1 || step === 1.5) {
      clearVoterSession();
    }
  }, [view, step, studentId, selectedPhone, isAdminPath]);

  // --- HANDLERS ---
  // BallotBox calls this on a 401 from /vote-bulk (token missing/expired/
  // replaced by a newer login). Their ballot picks are kept in sessionStorage.
  const handleSessionExpired = (detail) => {
    clearVoterSession();
    setOtp("");
    setStep(1);
    setStatusModal({
      show: true,
      title: "Session Expired",
      message: (typeof detail === "string" && detail) ||
        "Your voting session has expired. Please verify again. Your selections have been kept.",
      type: "error"
    });
  };

  const handleVoteSuccess = () => {
    // 1. Create the cookie
    const expiry = new Date();
    expiry.setSeconds(expiry.getSeconds() + 86400); 
    
    // 2. Save it to the browser
    document.cookie = `voted_status=true; expires=${expiry.toUTCString()}; path=/; SameSite=Lax`;

    // 3. The one-time voting token is spent — drop it and move to the final screen
    clearVoterToken();
    setStep(4);
  };

const needsCaptcha = !isAdminPath && turnstileConfigured
    && (captchaForced || electionStatus?.turnstile_mode === 'on');
  const captchaPending = needsCaptcha && !captchaToken;

// Voter <-> admin switch. The two forms share the same state (the voter's "full name" field and the
// admin's password field are the same variable), so without this a typed admin password would show up
// as plain text in the voter form, and a voter's name would land in the password field where the eye
// button could reveal it. Wipe every field, the 2FA prompt and the "show password" toggle on every switch.
const switchLoginMode = () => {
  setStudentId("");
  setName("");
  setTotpCode("");
  setNeedsTotp(false);
  setShowAdminPassword(false);
  setIsAdminPath(prev => !prev);
};

const handleVerifyIdentity = async (selectedIdx = null) => {
      if (selectedIdx !== null && selectedIdx !== undefined) phoneIdxRef.current = selectedIdx;
      setIsVerifying(true);
      try {
        const endpoint = isAdminPath ? "/verify-admin" : "/verify-identity";
      
        const payload = isAdminPath
          ? { email: studentId, password: name, totp_code: totpCode || undefined }
          : { student_id: studentId, full_name: name, phone_index: selectedIdx, turnstile_token: captchaToken || undefined };
    
        const res = await api.post(endpoint, payload);
  
        if (res.data.bypass === true) {
          sessionStorage.setItem("admin_role", res.data.role);
          setAdminRole(res.data.role);
          if (res.data.access_token) {
            sessionStorage.setItem(ADMIN_TOKEN_KEY, res.data.access_token);
          }
          if (res.data.commissioner_id) {
            sessionStorage.setItem("commissioner_id", res.data.commissioner_id);
          }
          if (res.data.it_admin_id) {
            sessionStorage.setItem("it_admin_id",   res.data.it_admin_id);
            sessionStorage.setItem("it_admin_name", res.data.full_name || "");
          }
          if (res.data.financial_controller_id) {
            sessionStorage.setItem("financial_controller_id", res.data.financial_controller_id);
            sessionStorage.setItem("financial_controller_name", res.data.full_name || "");
          }
          if (res.data.overseer_id) {
            sessionStorage.setItem("overseer_id", res.data.overseer_id);
            sessionStorage.setItem("overseer_name", res.data.full_name || "");
          }
        
          if (res.data.role !== "superadmin" && res.data.must_change_password) {
            markPasswordChangePending();
            setPendingAdminEmail(studentId);
            setPendingTempPassword(name); // `name` holds the password field for the admin login path
            setMustChangePassword(true);
            return;
          }
        
          setView(res.data.role);
          return;
        }
        sessionStorage.setItem("admin_role",res.data.role || "commission");
        setAdminRole(res.data.role || "commission");
  
        if (res.data.status === "needs_selection") {
          setMaskedNumbers(res.data.masked_numbers);
          setStep(1.5);
        } else {
          if (res.data.phone) {
            setSelectedPhone(res.data.phone);
          }
          
          setOtpFeedback(null);   // a fresh code: forget the previous attempt's error
          setStatusModal({
            show: true,
            title: "Code Sent!",
            message: (res.data.message || `We sent a verification code to ${res.data.phone || 'your phone'}.`)
              + (res.data.delivery === "unconfirmed" ? UNCONFIRMED_DELIVERY_NOTE : ""),
            type: "success"
          });
          
          setStep(2);
          setTimer(60);
          saveResendDeadline(60);
        }
      } catch (err) {
        // Superadmin credentials matched but no code was entered yet — reveal
        // the field and let them submit again, rather than showing this as
        // a login failure. This is the only path that turns needsTotp on,
        // so the field only ever appears once email+password have actually
        // matched the superadmin account.
        if (isAdminPath && err.response?.status === 428 && err.response?.data?.detail === "totp_required") {
          setNeedsTotp(true);
          setIsVerifying(false);
          return;
        }
        if (!isAdminPath && err.response?.data?.reason === "captcha_required") setCaptchaForced(true);
        const errorData = err.response?.data?.detail || (err.response ? "Verification Failed"
          : (navigator.onLine === false ? "You are offline. Reconnect and try again." : "No response from the server. Check your connection and try again."));
        // The schedule changed after this page loaded: re-read the status so the notice says
        // the right thing (not started yet vs. ended) instead of guessing from the error text.
        if (!isAdminPath && err.response?.status === 403 && /closed|has ended/i.test(String(errorData))) {
          api.get('/election-status').then(r => { setIsElectionOpen(r.data.is_open); setElectionStatus(r.data); }).catch(() => {});
        }
        // Voter path: say what to DO next, not just what went wrong (guide 4.3). Admin path keeps the raw text.
        const guide = isAdminPath
          ? { title: "Login Error", message: typeof errorData === 'object' ? JSON.stringify(errorData) : errorData }
          : loginGuidance(errorData, err.response?.data?.reason);
        setStatusModal({ show: true, title: guide.title, message: guide.message, type: "error", action: guide.action, support: guide.support });
      } finally {
        setIsVerifying(false);
        if (!isAdminPath) { setCaptchaToken(""); setCaptchaKey(k => k + 1); }
      }
    };

   const handleVerifyOtp = async () => {
    setIsVerifying(true);
    try {
      const otpRes = await api.post('/verify-otp', {
        student_id: studentId,
        code: otp
      });

      // The server issues a one-time voting token on a correct OTP; the
      // /vote-* calls send it (see api.js) and it lets a reload resume the ballot.
      if (!isAdminPath && otpRes.data?.voter_token) saveVoterToken(otpRes.data.voter_token);
  
      setOtp("");
      setOtpFeedback(null);
  
      if (isAdminPath) {
        setStatusModal({
          show: true,
          title: "Admin Authorised",
          message: "Welcome back. You now have access to the election controls.",
          type: "success"
        });
  
        sessionStorage.setItem("commissioner_id", studentId);
  
        const role = sessionStorage.getItem("admin_role");
        setView(role === "superadmin" ? "superadmin" : (role || "commission"));
      } else {
        setStep(3);
      }
    } catch (err) {
      const data = err.response?.data || {};
      if (['wrong_code', 'guess_lock', 'no_live_code'].includes(data.reason)) {
        // Shown inline by OtpInput (red border, tries left, live lockout countdown). The typed code stays in the
        // field so a single wrong digit can be fixed instead of retyping all six.
        setOtpFeedback({
          reason: data.reason, message: data.detail, attempts_remaining: data.attempts_remaining,
          lock_until: data.reason === 'guess_lock' && data.retry_after ? Date.now() + data.retry_after * 1000 : undefined,
        });
      } else {
        const errorMsg = data.detail || (err.response ? "Invalid or expired code. Please try again."
          : "No response from the server. Check your connection and try again.");
        setStatusModal({ show: true, title: "Verification Failed", message: errorMsg, type: "error" });
      }
    } finally {
      setIsVerifying(false);
    }
  };

    const handleSetNewPassword = async (e) => {
    e.preventDefault();
    setPasswordChangeError('');
  
    if (newPasswordForm.new_password.length < 10) {
      setPasswordChangeError('New password must be at least 10 characters and mix three of: lower, upper, numbers, symbols.');
      return;
    }
    if (newPasswordForm.new_password !== newPasswordForm.confirm_password) {
      setPasswordChangeError('Passwords do not match.');
      return;
    }
  
    setPasswordChangeSubmitting(true);
    try {
      await api.post('/admin/set-password', {
        email:        pendingAdminEmail,
        old_password: pendingTempPassword,
        new_password: newPasswordForm.new_password,
      });
  
      // Re-run login with the new password to get the role and proceed
      const res = await api.post('/verify-admin', {
        email: pendingAdminEmail,
        password: newPasswordForm.new_password,
      });
  
      sessionStorage.setItem("admin_role", res.data.role);
      setAdminRole(res.data.role);
      if (res.data.access_token) {
        sessionStorage.setItem(ADMIN_TOKEN_KEY, res.data.access_token);
      }
      if (res.data.commissioner_id) sessionStorage.setItem("commissioner_id", res.data.commissioner_id);
      if (res.data.it_admin_id) {
        sessionStorage.setItem("it_admin_id",   res.data.it_admin_id);
        sessionStorage.setItem("it_admin_name", res.data.full_name || "");
      }
      if (res.data.financial_controller_id) {
          sessionStorage.setItem("financial_controller_id", res.data.financial_controller_id);
          sessionStorage.setItem("financial_controller_name", res.data.full_name || "");
      }
      if (res.data.overseer_id) {
          sessionStorage.setItem("overseer_id", res.data.overseer_id);
          sessionStorage.setItem("overseer_name", res.data.full_name || "");
      }
  
      clearPasswordChangePending();
      setMustChangePassword(false);
      setPendingTempPassword('');
      setNewPasswordForm({ new_password: '', confirm_password: '' });
      setView(res.data.role);
    } catch (err) {
      setPasswordChangeError(err.response?.data?.detail || 'Failed to update password.');
    } finally {
      setPasswordChangeSubmitting(false);
    }
  };
  
  const resetFlow = () => {
    // Best-effort server-side revocation — fire and forget, don't block the
    // UI on it. Client-side clearing below happens regardless, so a failed
    // revoke call never traps the user on a stuck screen.
    if (sessionStorage.getItem(ADMIN_TOKEN_KEY)) {
      api.post("/admin/logout").catch(() => {});
    }
    setStep(1);
    setView("voter");
    setIsAdminPath(false);
    setStudentId("");
    setName("");
    setOtp("");
    setTotpCode("");
    setNeedsTotp(false);
    setMaskedNumbers([]);
    setTimer(0);
    setSelectedPhone("");
    setAdminRole(null);
    // Full sign-out: admin token/role/ids/remembered tabs, the voter session
    // and saved ballot picks, and the remembered public page.
    clearAdminSession();
    clearVoterProgress();
    savePublicView(null);
  };

  // "Vote Now" is a full sign-out (resetFlow). A signed-in admin who taps it by accident would lose
  // their session, so ask first. No admin token -> no dialog (plain voter reset). (WP-7c)
  const confirmDialog = useOptionalConfirm();
  const handleVoteNow = async () => {
    if (sessionStorage.getItem(ADMIN_TOKEN_KEY)
      && !(await confirmDialog("You will be signed out. Continue?", {
        title: 'Sign out?', confirmText: 'Sign out', cancelText: 'Stay signed in',
      }))) {
      return;
    }
    resetFlow();
  };

  if (!bootReady) {
    if (!bootSplashDue) return null;   // still inside the warm-server grace period
    return <BootSplash orgName={bootName} logoUrl={bootLogoUrl} exiting={bootExiting} stage={bootStage} />;
  }

  // candidate-portal-spec §4.1: a public, token-linked status page, reachable
  // by URL rather than a nav click (same idea as ApplicantPortal). No router
  // exists in this app, so this is a plain pathname check — skips all of the
  // view/step/session restoration above entirely. frontend/vercel.json's SPA
  // catch-all already rewrites any path to /index.html, so a cold hit here
  // loads the app shell before this check runs; no Vercel config change needed.
  if (statusToken) {
    return <Suspense fallback={<LoadingBlock text="Loading…" />}><CandidateStatusPortal token={statusToken} /></Suspense>;
  }
  // What a certificate's QR code opens — public, read-only (see VerifyCertificate).
  if (verifyId) {
    return <Suspense fallback={<LoadingBlock text="Loading…" />}><VerifyCertificate certificateId={verifyId} /></Suspense>;
  }

  // Blueprint template seam (BP-T2): null in the default UI, so every branch below falls through to today's markup.
  const bp = getTemplate();
  // Public views get the template's 520px column; the default UI gets the node back untouched (no extra div).
  // Class hooks for the voter flow (undefined in the default UI, so no class attribute is added there).
  const k = bp ? bp.cls : null;
  const cardProps = () => (bp ? { className: k.card } : { style: cardStyle });
  const wrapPublic = (node, wide = false) => (bp ? <bp.PublicWrap wide={wide}>{node}</bp.PublicWrap> : node);

  return (
    <HelpMenuProvider>
    <DemoInbox />
    <div style={containerStyle} className="app-shell">
      {(view === "voter" || view === "apply") && (
        <>
          <HelpPanel
            supportPhone={supportPhone}
            supportContacts={supportContacts}
            orgName={orgName}
            onShowGuide={() => setShowGuide(true)}
            page={view}
          />
          {/* Ballot page (step 3) puts Help inside its own footer bar via
              <InlineHelpButton /> — see BallotBox.jsx — so the floating
              trigger only renders when nothing else owns that space.
              The Apply page has no ballot footer, so it gets the floating
              trigger too, icon-only (see showHelpFab in helpItems.js). */}
          {showHelpFab(view, step) && <FabTrigger compact={view === "apply"} />}
        </>
      )}
      <div style={{ 
          width: '100%', 
          // Admin-type dashboards manage their own width (rail + content
          // card, see SuperAdminDashboard's outerWrap/.dash-body) and need
          // the full viewport to do it — capping this wrapper at 1200px
          // silently overrode all of that from one level up, which is why
          // widening the dashboard's own CSS never actually reached the
          // screen. Only the voter/apply flow still wants a narrow, centered
          // column here.
          maxWidth: (view === "admin" || view === "results" || view === "superadmin" || view === "commission" || view === "it_admin" || view === "financial_controller" || view === "overseer" || view === "vetting") ? '100%' : '500px',
          margin: '0 auto',
          transition: 'max-width 0.3s ease' 
        }} className="app-column">
        
        {bp ? (
          <bp.TitleBlockHeader
            orgName={orgName}
            logoUrl={logoUrl}
            logoNeedsInvert={logoNeedsInvert}
            status={electionStatus}
            view={view}
            step={step}
            theme={theme}
            onToggleTheme={toggleTheme}
            onVoteNow={handleVoteNow}
            onNavigate={setView}
            showBackToAdmin={Boolean(adminRole && (view === "results" || view === "apply"))}
            onBackToAdmin={() => setView(adminRole)}
            role={bp.ROLE_LABELS[view] || ''}
          />
        ) : (
          <nav className="no-print" style={navBarStyle}>
            <div style={{ display: 'flex', justifyContent: 'flex-end', width: '100%' }}>
              <button
                onClick={toggleTheme}
                title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
                style={{
                  background: 'none', border: '1px solid var(--border-color)',
                  borderRadius: '20px', padding: '6px 12px', cursor: 'pointer',
                  fontSize: '13px', color: 'var(--text-color)',
                  display: 'flex', alignItems: 'center', gap: '6px',
                }}
              >
                {theme === 'dark' ? <>Light</> : <>Dark</>}
              </button>
            </div>
            {logoUrl && <img src={logoUrl} alt="Logo" style={logoStyle} />}
            <span style={{
              color: 'var(--text-color)',
              fontSize: '13px',
              fontWeight: '700',
              letterSpacing: '1px',
              textTransform: 'uppercase',
              opacity: 0.8,
              marginTop: '-10px',
              textAlign: 'center'
            }}>
              {orgName} Election Portal
            </span>
          
            <div style={{ display: 'flex', gap: '20px', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap' }}>
              <button data-track="nav-vote" onClick={handleVoteNow} style={view === "voter" && step === 1 ? activeNavBtnStyle : navBtnStyle}>
                Vote Now
              </button>
        
              <button data-track="nav-results" onClick={() => setView("results")} style={view === "results" ? activeNavBtnStyle : navBtnStyle}>
                Live Results
              </button>
        
              <button data-track="nav-apply" onClick={() => setView("apply")} style={view === "apply" ? activeNavBtnStyle : navBtnStyle}>
                Apply
              </button>

              {/* Deliberately NOT shown while view === "voter": that flow is
                  someone actively proving they're a different identity (via
                  OTP), and a leftover admin session from earlier in the tab
                  has nothing to do with who's typing right now. Showing this
                  shortcut there meant anyone who knew an admin's voter
                  credentials (student ID + name — not a secret) could open
                  the voter OTP screen and skip straight into the admin
                  dashboard with zero re-authentication, on any device/tab
                  where an admin had once logged in and not explicitly logged
                  out. Restricted to results/apply — the two read-only pages
                  this was actually built for. */}
              {adminRole && (view === "results" || view === "apply") && (
                <button onClick={() => setView(adminRole)} style={backToAdminBtnStyle}>
                  Back to Admin
                </button>
              )}
            </div>
          </nav>
        )}

        <Suspense fallback={<LoadingBlock text="Loading…" />}>
        {view === "results" && wrapPublic(<Results apiBase={API_BASE} />, true)}
        {view === "superadmin" && <SuperAdminDashboard onLogout={resetFlow} />}
        {view === "commission" && <CommissionDashboard onLogout={resetFlow} />}
        {view === "apply" && wrapPublic(<ApplicantPortal />)}
        {view === "it_admin" && <ITAdminDashboard onLogout={resetFlow} />}
        {view === "financial_controller" && <FinancialControllerDashboard onLogout={resetFlow} />}
        {view === "overseer" && <OverseerDashboard onLogout={resetFlow} />}
        {view === "vetting" && <VettingDashboard onLogout={resetFlow} />}
        {HEATMAP_FRAME
          ? <HeatmapOverlay embedded page={HEATMAP_FRAME.page} />
          : window.self === window.top && view !== "voter" && sessionStorage.getItem('admin_role') === 'superadmin' && <HeatmapOverlay />}
        </Suspense>
        
        
        {view === "voter" && wrapPublic((
          <div style={{ width: '100%' }}>
            {step === 1 && (
              <div {...cardProps()}>
              <h1 style={{ textAlign: 'center', color: 'var(--text-color)' }}>
                {isAdminPath ? "Admin Login" : "Voter Login"}
              </h1>
              {!isAdminPath && !bp && <PhaseBanner status={electionStatus} onApply={() => setView("apply")} />}
              
              {isAdminPath ? (
                <>
                  {bp && <bp.FieldLabel htmlFor="admin-email">Email address</bp.FieldLabel>}
                  <input
                    key="admin-email"
                    name="admin-email"
                    id={bp ? 'admin-email' : undefined}
                    className={k?.in}
                    style={bp ? undefined : inputStyle}
                    value={studentId}
                    onChange={e => { setStudentId(e.target.value); setNeedsTotp(false); setTotpCode(""); }}
                    placeholder="Email address"
                    type="email"
                    autoComplete="email"
                  />
                  {bp && <bp.FieldLabel htmlFor="admin-password">Password</bp.FieldLabel>}
                  <div style={{ position: 'relative', marginBottom: '15px' }}>
                    <input
                      key="admin-password"
                      name="admin-password"
                      id={bp ? 'admin-password' : undefined}
                      className={k?.in}
                      style={bp ? { marginBottom: 0, paddingRight: '46px' } : { ...inputStyle, marginBottom: 0, paddingRight: '46px' }}
                      value={name}
                      onChange={e => { setName(e.target.value); setNeedsTotp(false); setTotpCode(""); }}
                      placeholder="Password e.g. Comm@2026!"
                      type={showAdminPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowAdminPassword(v => !v)}
                      aria-label={showAdminPassword ? 'Hide password' : 'Show password'}
                      aria-pressed={showAdminPassword}
                      title={showAdminPassword ? 'Hide password' : 'Show password'}
                      style={{ position: 'absolute', top: 0, bottom: 0, right: 0, width: '44px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted, #64748b)' }}
                    >
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" />
                        <circle cx="12" cy="12" r="3" />
                        {showAdminPassword && <line x1="3" y1="3" x2="21" y2="21" />}
                      </svg>
                    </button>
                  </div>
                  {needsTotp && bp && <bp.FieldLabel htmlFor="admin-totp">Authenticator code</bp.FieldLabel>}
                  {needsTotp && (
                    <input
                      id={bp ? 'admin-totp' : undefined}
                      className={k?.in}
                      style={bp ? undefined : inputStyle}
                      value={totpCode}
                      onChange={e => setTotpCode(e.target.value)}
                      placeholder="Authenticator code"
                      type="text"
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={6}
                      autoFocus
                    />
                  )}
                </>
              ) : (
                <>
                  <VoterLoginInputs studentId={studentId} setStudentId={setStudentId} name={name} setName={setName} inputStyle={inputStyle} />
                </>
              )}
              
              {needsCaptcha && <TurnstileWidget onToken={setCaptchaToken} resetKey={captchaKey} />}
              <button
                data-track="login-submit"
                onClick={() => handleVerifyIdentity()}
                disabled={(!isElectionOpen && !isAdminPath) || isVerifying || captchaPending}
                className={k?.btn}
                style={bp ? { opacity: isVerifying ? 0.7 : 1, cursor: isVerifying ? 'wait' : 'pointer' } : {
                  ...primaryBtnStyle,
                  backgroundColor: (isElectionOpen || isAdminPath) ? 'var(--success)' : '#bdc3c7',
                  opacity: isVerifying ? 0.7 : 1,
                  cursor: isVerifying ? 'wait' : 'pointer',
                }}
              >
                {isVerifying ? <><Icon name="loading" /> Verifying…</> : (isAdminPath ? "Log In" : "Verify & Send Code")}
              </button>
              <button data-track="login-switch-admin" onClick={switchLoginMode} className={k?.lnk} style={bp ? undefined : linkBtnStyle}>
                {isAdminPath ? "Switch to Voter Login" : "Are you an admin? Log in here"}
              </button>
              </div>
            )}

            {step === 1.5 && (
              <div {...cardProps()}>
                <h2 style={{ textAlign: 'center' }}>Select Phone Number</h2>
                <p style={{ textAlign: 'center', opacity: 0.8, marginBottom: '20px' }}>Choose where to receive your code:</p>
                {needsCaptcha && <TurnstileWidget onToken={setCaptchaToken} resetKey={captchaKey} />}
                  {maskedNumbers.map((num, index) => (
                  <button
                    key={index}
                    onClick={() => { setSelectedPhone(num); handleVerifyIdentity(index); }}
                    disabled={isVerifying || captchaPending}
                    className={k?.ghost}
                    style={bp ? { opacity: isVerifying ? 0.6 : 1, cursor: isVerifying ? 'wait' : 'pointer' } : { ...selectionBtnStyle, opacity: isVerifying ? 0.6 : 1, cursor: isVerifying ? 'wait' : 'pointer' }}
                  >
                    {isVerifying ? 'Sending…' : `Receive code on ${num}`}
                  </button>
                ))}
                <button onClick={() => setStep(1)} className={k?.lnk} style={bp ? undefined : { ...linkBtnStyle, color: 'var(--danger)' }}>Cancel</button>
              </div>
            )}

            {step === 2 && (
              <div {...cardProps()}>
               <OtpInput otp={otp} feedback={otpFeedback}
                 setOtp={(v) => { setOtp(v); setOtpFeedback(f => (f && !f.lock_until ? null : f)); }}   // editing clears a plain error, never a lockout
                 onVerify={handleVerifyOtp} phoneNumber={selectedPhone} onBack={() => setStep(1)} isSubmitting={isVerifying}
                 supportPhone={supportPhone || supportContacts[0]?.contacts?.[0]?.link || ''} orgName={orgName} studentId={studentId} />
                <div style={{ marginTop: '20px', textAlign: 'center' }}>
                  {timer > 0 ? (
                    <p style={{ fontSize: '14px', opacity: 0.7 }}>Resend in <b>{timer}s</b></p>
                  ) : (
                    <>
                      {needsCaptcha && <TurnstileWidget onToken={setCaptchaToken} resetKey={captchaKey} />}
                      <button data-track="otp-resend" onClick={() => handleVerifyIdentity(phoneIdxRef.current)} disabled={captchaPending || isVerifying}
                        className={k?.sm}
                        style={bp ? { opacity: captchaPending ? 0.5 : 1 } : { ...resendBtnStyle, opacity: captchaPending ? 0.5 : 1 }}>Resend SMS</button>
                    </>
                  )}
                </div>
              </div>
            )}

            {step === 3 && (
              <BallotBox 
                studentId={studentId} 
                onVoteSuccess={handleVoteSuccess}
                onSessionExpired={handleSessionExpired}
                apiBase={API_BASE} 
                propCandidates={candidates.length ? candidates : undefined}   // undefined => BallotBox shows its own loading state and fetches
                orgName={orgName}
              />
            )}
            
            {step === 4 && (
              <div style={{ ...cardStyle, textAlign: 'center' }} className="panel-fade-in">
                <svg width="72" height="72" viewBox="0 0 72 72" style={{ margin: '0 auto 12px' }}>
                  <circle cx="36" cy="36" r="34" fill="none" stroke="var(--success)" strokeWidth="3"
                    strokeDasharray="214" strokeDashoffset="214" style={{ animation: 'vote-circle-draw 0.5s ease-out forwards' }} />
                  <path d="M20 37 L31 47 L52 24" fill="none" stroke="var(--success)" strokeWidth="4"
                    strokeLinecap="round" strokeLinejoin="round" strokeDasharray="42" strokeDashoffset="42"
                    style={{ animation: 'vote-check-draw 0.35s ease-out 0.4s forwards' }} />
                </svg>
                <h2 style={{ color: 'var(--success)' }}>Vote Cast Successfully!</h2>
                <button onClick={resetFlow} style={{ ...primaryBtnStyle, backgroundColor: 'var(--bp-ok, #2ecc71)' }}>Return Home</button>
              </div>
            )}
          </div>
        ))}

        {mustChangePassword && (
          <div className="overlay-fade-in" style={modalOverlayStyle}>
            <div className="modal-content panel-fade-in" role="dialog" aria-modal="true" aria-label="Set a new password" style={{ ...modalContentStyle, maxWidth: '420px' }}>
              <h2 style={{ textAlign: 'center', marginTop: 0, color: 'var(--text-color)' }}>Set a New Password</h2>
              <p style={{ textAlign: 'center', fontSize: '13px', color: 'var(--text-muted)', marginBottom: '20px' }}>
                For your security, you must set a new password before continuing.
              </p>
        
               <form onSubmit={handleSetNewPassword}>
                <input
                  type="password"
                  placeholder="New password (min 6 characters)"
                  style={inputStyle}
                  value={newPasswordForm.new_password}
                  onChange={e => setNewPasswordForm({ ...newPasswordForm, new_password: e.target.value })}
                  disabled={passwordChangeSubmitting}
                />
                <input
                  type="password"
                  placeholder="Confirm new password"
                  style={inputStyle}
                  value={newPasswordForm.confirm_password}
                  onChange={e => setNewPasswordForm({ ...newPasswordForm, confirm_password: e.target.value })}
                  disabled={passwordChangeSubmitting}
                />
        
                {passwordChangeError && (
                  <p style={{ color: 'var(--danger)', fontSize: '13px', textAlign: 'center', marginBottom: '10px' }}>
                    <Icon name="warning" /> {passwordChangeError}
                  </p>
                )}
        
                <button
                  type="submit"
                  style={{
                    ...primaryBtnStyle,
                    backgroundColor: 'var(--success)',
                    opacity: passwordChangeSubmitting ? 0.7 : 1,
                    cursor: passwordChangeSubmitting ? 'wait' : 'pointer',
                  }}
                  disabled={passwordChangeSubmitting}
                >
                  {passwordChangeSubmitting ? <><Icon name="loading" /> Setting password…</> : 'Set Password & Continue'}
                </button>
              </form>
            </div>
          </div>
        )}
        
        {statusModal.show && (
          <div className="overlay-fade-in" style={modalOverlayStyle}>
            <div className="modal-content panel-fade-in" role="dialog" aria-modal="true" aria-label={statusModal.type === 'success' ? 'Success' : 'Notice'} style={modalContentStyle}>
              <div style={{ fontSize: '50px', marginBottom: '10px', textAlign: 'center' }}>
                {statusModal.type === 'success' ? <Icon name="success" /> : <Icon name="warning" />}
              </div>
              <h2 style={{ color: statusModal.type === 'success' ? 'var(--success)' : 'var(--danger)', textAlign: 'center', marginTop: 0 }}>
                {statusModal.title}
              </h2>
              <p style={{ textAlign: 'center', marginBottom: '20px', color: 'var(--text-muted)' }}>{statusModal.message}</p>
              {statusModal.type !== 'success' && (
                <LoginErrorActions action={statusModal.action} support={statusModal.support}
                  supportContact={supportPhone || supportContacts[0]?.contacts?.[0]?.link || ''} orgName={orgName} studentId={studentId}
                  onNavigate={() => setStatusModal({ ...statusModal, show: false })} />
              )}
              <button 
                onClick={() => setStatusModal({ ...statusModal, show: false })} 
                style={{ ...primaryBtnStyle, backgroundColor: statusModal.type === 'success' ? 'var(--success)' : 'var(--info)' }}
              >
                {statusModal.type === 'success' ? 'Continue' : 'Try Again'}
              </button>
            </div>
          </div>
        )}
      </div>
            {/* --- FULL PAGE BALLOT GUIDE --- */}
      {showGuide && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100vh',
          backgroundColor: 'var(--bg-color)',
          zIndex: 5000, // Highest z-index to cover everything
          overflowY: 'auto',
          padding: '20px'
        }}>
          <div style={{ maxWidth: '800px', margin: '0 auto' }}>
            {/* Back Button */}
            <button 
              onClick={() => setShowGuide(false)}
              style={{
                backgroundColor: '#34495e',
                color: '#fff',
                border: 'none',
                padding: '12px 20px',
                borderRadius: '8px',
                cursor: 'pointer',
                marginBottom: '20px',
                fontWeight: 'bold',
                fontSize: '16px'
              }}
            >
              Back to Login
            </button>
      
            {/* Reusing BallotBox in Preview Mode */}
           <BallotBox 
              candidates={candidates} 
              isPreview={true} 
              apiBase={API_BASE}
              orgName={orgName}
            />
            
            <div style={{ textAlign: 'center', padding: '40px 0', color: '#94a3b8' }}>
              <p>This is a guide. Log in to cast your actual vote.</p>
            </div>
          </div>
        </div>
      )}
    </div>
    </HelpMenuProvider>
  );
}

// --- STYLES ---
// A boot-time splash, shown until /health confirms this tenant's backend is
// actually up (see the effect above). The name/logo come from build-time env
// vars (VITE_ELECTION_NAME / VITE_LOGO_URL) so they're present on the very
// first frame — no network round-trip to wait on for those. If the Mongo-
// backed /superadmin/branding call later returns a different name/logo,
// App.jsx updates the props in place; since the splash is still showing the
// same *kind* of content (a name, a mark), that swap doesn't need its own
// transition. "exiting" drives the hand-off animation to the real app once
// /health resolves — same pattern as eregistry.ursb.go.ug's
// "Initializing secure session" screen.
const BOOT_STAGES = {
  connecting:   { label: 'CONNECTING',                      dot: 'var(--warning, #eab308)', text: 'Loading election details…' },
  starting:     { label: 'STARTING SERVER',                 dot: 'var(--warning, #eab308)', text: 'The server is waking up after a period of inactivity. This can take up to a minute. Thanks for your patience.' },
  initializing: { label: 'INITIALIZING SECURE CONNECTION',  dot: 'var(--brand-primary, #2563eb)', text: 'Server is up. Setting up a secure connection…' },
  connected:    { label: 'CONNECTED',                       dot: 'var(--success, #22c55e)', text: 'Secure connection established.' },
};

function BootSplash({ orgName, logoUrl, exiting, stage }) {
  const st = BOOT_STAGES[stage] || BOOT_STAGES.connecting;
  const bp = getTemplate();
  // Blueprint look: same stages, copy and dot colours; the spinner ring becomes the initials stamp.
  if (bp) return <bp.BootSplash orgName={orgName} logoUrl={logoUrl} exiting={exiting} text={st.text} label={st.label} dot={st.dot} />;
  return (
    <div style={{ ...bootWrapStyle, ...(exiting ? bootWrapExitStyle : null) }}>
      <div style={bootCardStyle}>
        <div style={bootSpinnerStyle}>
          {logoUrl
            ? <img src={logoUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'contain', borderRadius: '8px' }} />
            : <span style={bootSpinnerRingStyle} />}
        </div>
        <h1 style={bootTitleStyle}>{orgName || 'Election Portal'}</h1>
        <p style={bootSubtitleStyle} aria-live="polite">{st.text}</p>
        <div style={bootStatusRowStyle} role="status">
          <span style={{ ...bootDotStyle, background: st.dot, transition: 'background 0.3s ease' }} />
          {st.label}
        </div>
      </div>
    </div>
  );
}

const bootWrapStyle = {
  position: 'fixed', inset: 0, zIndex: 9999,
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  background: 'var(--bg-color, #f4f6fb)', padding: '20px', boxSizing: 'border-box',
  opacity: 1, transform: 'scale(1)',
  transition: 'opacity 0.35s ease, transform 0.35s ease',
};

// Applied for the final 350ms (EXIT_ANIM_MS in the boot effect, above) once
// /health has resolved — a soft fade + scale rather than a hard unmount, so
// the real app appears as a deliberate hand-off instead of a jump-cut.
const bootWrapExitStyle = {
  opacity: 0, transform: 'scale(1.02)',
  pointerEvents: 'none',
};
const bootCardStyle = {
  width: '100%', maxWidth: '380px', textAlign: 'center',
  background: 'var(--card-bg, #fff)', borderRadius: '20px',
  padding: '48px 32px', boxShadow: '0 10px 40px rgba(0,0,0,0.08)',
  border: '1px solid var(--border-color, #e5e9f2)',
};
const bootSpinnerStyle = {
  width: '84px', height: '84px', margin: '0 auto 22px',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
};
const bootSpinnerRingStyle = {
  display: 'block', width: '56px', height: '56px', borderRadius: '50%',
  border: '3px solid transparent',
  borderTopColor: 'var(--brand-primary, #2563eb)',
  borderBottomColor: 'var(--brand-primary, #2563eb)',
  animation: 'boot-spin 0.9s linear infinite',
};
const bootTitleStyle = {
  margin: '0 0 10px', fontSize: '26px', fontWeight: 800,
  color: 'var(--brand-primary, #1d4ed8)', letterSpacing: '0.3px',
};
const bootSubtitleStyle = {
  margin: '0 0 22px', fontSize: '14px', lineHeight: 1.5,
  color: 'var(--text-muted, #64748b)',
};
const bootStatusRowStyle = {
  display: 'inline-flex', alignItems: 'center', gap: '8px',
  fontSize: '11px', fontWeight: 700, letterSpacing: '1px',
  color: 'var(--text-muted, #64748b)',
};
const bootDotStyle = { width: '8px', height: '8px', borderRadius: '50%', flexShrink: 0 };

// The keyframes are injected once, globally — App.jsx has no CSS module of
// its own, and this animation is only ever used by BootSplash.
if (typeof document !== 'undefined' && !document.getElementById('boot-spin-keyframes')) {
  const style = document.createElement('style');
  style.id = 'boot-spin-keyframes';
  style.textContent = '@keyframes boot-spin { to { transform: rotate(360deg); } }';
  document.head.appendChild(style);
}

const containerStyle = { display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', backgroundColor: 'var(--bg-color)', padding: '20px', boxSizing: 'border-box' };

const navBarStyle = { marginBottom: '30px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', gap: '16px', padding: '15px 0', width: '100%', borderBottom: '1px solid var(--border-color)' };


const navBtnStyle = {
  padding: '10px 24px',
  backgroundColor: 'var(--brand-primary, #003366)',
  color: 'var(--brand-on-primary, white)',
  border: '2px solid var(--brand-accent, #f1c40f)',
  borderRadius: '30px',
  cursor: 'pointer',
  fontWeight: '600',
  fontSize: '14px',
  transition: 'all 0.3s ease',
  boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
  textTransform: 'uppercase',
  letterSpacing: '1px'
};

const activeNavBtnStyle = {
  ...navBtnStyle,
  backgroundColor: 'var(--brand-accent, #f1c40f)',
  color: 'var(--brand-on-accent, #003366)',
  borderColor: 'var(--brand-primary, #003366)'
};

// Only shown when an admin session exists (sessionStorage's "admin_role")
// and the visitor has clicked away from their dashboard — e.g. to preview
// Live Results — so they never have to refresh or use "Vote Now" (which
// signs them out) just to get back to where they were logged in.
const backToAdminBtnStyle = {
  ...navBtnStyle,
  display: 'flex',
  alignItems: 'center',
  gap: '6px',
  backgroundColor: 'transparent',
  color: 'var(--brand-accent, #f1c40f)',
  borderStyle: 'dashed',
};

const cardStyle = { background: 'var(--card-bg)', color: 'var(--text-color)', padding: '30px', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', border: '1px solid var(--border-color)', width: '100%', boxSizing: 'border-box' };

const inputStyle = { display: 'block', width: '100%', marginBottom: '15px', padding: '12px', borderRadius: '6px', border: '1px solid var(--border-color)', backgroundColor: 'var(--bg-color)', color: 'var(--text-color)', boxSizing: 'border-box' };

const primaryBtnStyle = { width: '100%', padding: '12px', color: 'white', border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', transition: 'transform 0.1s' };


const modalOverlayStyle = { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(15, 23, 42, 0.9)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 3000, backdropFilter: 'blur(4px)' };

const modalContentStyle = { backgroundColor: 'var(--card-bg)', padding: '32px', borderRadius: '20px', width: '90%', maxWidth: '400px', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)', zIndex: 3001 };

const selectionBtnStyle = { width: '100%', padding: '15px', backgroundColor: '#f8f9fa', color: '#2c3e50', border: '1px solid #dee2e6', borderRadius: '8px', marginBottom: '10px', textAlign: 'left', cursor: 'pointer' };

const linkBtnStyle = { background: 'none', border: 'none', color: '#007bff', cursor: 'pointer', marginTop: '15px', width: '100%' };

const resendBtnStyle = { background: 'none', border: '1px solid var(--bp-ok, #2ecc71)', color: 'var(--success)', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer', fontSize: '14px', fontWeight: '600' };

export default App;
